# Generated for B-UH granular Moon Mining visibility controls.

from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [("moonmining", "0007_add_localization")]

    operations = [
        migrations.AlterModelOptions(
            name="general",
            options={
                "default_permissions": (),
                "managed": False,
                "permissions": (
                    ("basic_access", "Can access the moonmining app"),
                    (
                        "extractions_access",
                        "Can access extractions and view owned moons",
                    ),
                    ("reports_access", "Can access reports"),
                    ("view_all_moons", "Can view all known moons"),
                    ("upload_moon_scan", "Can upload moon scans"),
                    ("add_refinery_owner", "Can add refinery owner"),
                    ("view_moon_ledgers", "Can view moon ledgers"),
                    (
                        "view_extraction_amounts",
                        "Can view extraction volume and estimated values",
                    ),
                    (
                        "view_extraction_details",
                        "Can view extraction detail actions",
                    ),
                    ("view_moon_details", "Can view moon detail actions"),
                    ("view_moon_values", "Can view estimated moon values"),
                ),
            },
        )
    ]
