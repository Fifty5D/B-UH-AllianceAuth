"""Alliance Auth app for tracking moon extractions and scouting new moons."""

# pylint: disable = invalid-name
default_app_config = "moonmining.apps.MoonMiningConfig"

__version__ = "3.1.0.post1"
__title__ = "Moon Mining"
