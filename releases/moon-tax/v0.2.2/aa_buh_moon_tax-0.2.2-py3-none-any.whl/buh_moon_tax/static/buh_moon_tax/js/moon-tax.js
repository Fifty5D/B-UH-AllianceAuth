(() => {
  "use strict";

  const setupAuditPolling = () => {
    const state = document.querySelector("[data-audit-url]");
    if (!state) return;
    const terminal = new Set(["COMPLETE", "WARNING", "FAILED"]);
    const poll = async () => {
      try {
        const response = await fetch(state.dataset.auditUrl, {
          headers: {"X-Requested-With": "XMLHttpRequest"},
        });
        if (response.ok) {
          const data = await response.json();
          const label = state.querySelector("[data-audit-label]");
          const summary = state.querySelector("[data-audit-summary]");
          if (label) label.textContent = data.status_label;
          state.className = `tax-audit-state ${data.status.toLowerCase()} mb-3`;
          if (summary && data.summary && Object.keys(data.summary).length) {
            summary.innerHTML = `<span>${data.summary.periods || 0} pulls</span><span>${data.summary.mining_lines_processed || 0} ledger rows</span><span>${data.summary.new_payment_candidates || 0} new payments</span>`;
          }
          if (terminal.has(data.status)) {
            window.setTimeout(() => window.location.reload(), 900);
            return;
          }
        }
      } catch (_) {
        // A temporary proxy or restart failure should not break the dashboard.
      }
      window.setTimeout(poll, 5000);
    };
    window.setTimeout(poll, 3000);
  };

  const setupPaymentFilters = () => {
    const panel = document.querySelector("[data-payment-filters]");
    if (!panel) return;
    const toggle = panel.querySelector("[data-toggle-advanced]");
    const advanced = panel.querySelector("[data-advanced-filters]");
    if (toggle && advanced) {
      toggle.addEventListener("click", () => {
        const open = advanced.classList.toggle("is-open");
        toggle.setAttribute("aria-expanded", String(open));
      });
    }
    document.querySelectorAll("[data-filter-member]").forEach((button) => {
      button.addEventListener("click", () => {
        const search = panel.querySelector("[data-payment-search]");
        if (!search) return;
        search.value = button.dataset.filterMember || "";
        search.form.submit();
      });
    });
  };

  const setupDensityToggle = () => {
    const list = document.querySelector("[data-payment-list]");
    const toggle = document.querySelector("[data-density-toggle]");
    if (!list || !toggle) return;
    const apply = (compact) => {
      list.classList.toggle("is-compact", compact);
      toggle.innerHTML = compact
        ? '<i class="fa-solid fa-expand"></i> Comfortable'
        : '<i class="fa-solid fa-compress"></i> Compact';
      toggle.setAttribute("aria-pressed", String(compact));
    };
    let compact = false;
    try {
      compact = window.localStorage.getItem("buh-moon-tax-payment-density") === "compact";
    } catch (_) {
      // Storage can be unavailable in hardened/private browser modes.
    }
    apply(compact);
    toggle.addEventListener("click", () => {
      compact = !list.classList.contains("is-compact");
      apply(compact);
      try {
        window.localStorage.setItem(
          "buh-moon-tax-payment-density",
          compact ? "compact" : "comfortable",
        );
      } catch (_) {
        // The preference is optional; the toggle still works for this page load.
      }
    });
  };

  const setupPaymentSelection = () => {
    const bulkForm = document.querySelector("#tax-bulk-form");
    const toolbar = document.querySelector("[data-bulk-toolbar]");
    const checkboxes = Array.from(document.querySelectorAll(".tax-payment-select"));
    if (!bulkForm || !toolbar || !checkboxes.length) return;

    const selectVisible = document.querySelector("[data-select-visible]");
    const countNode = toolbar.querySelector("[data-selected-count]");
    const totalNode = toolbar.querySelector("[data-selected-total]");
    const amountFormatter = new Intl.NumberFormat("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    let lastChecked = null;

    const selected = () => checkboxes.filter((checkbox) => checkbox.checked);
    const updateToolbar = () => {
      const chosen = selected();
      const total = chosen.reduce(
        (sum, checkbox) => sum + Number.parseFloat(checkbox.dataset.amount || "0"),
        0,
      );
      toolbar.hidden = chosen.length === 0;
      if (countNode) countNode.textContent = String(chosen.length);
      if (totalNode) totalNode.textContent = amountFormatter.format(total);
      if (selectVisible) {
        selectVisible.checked = chosen.length === checkboxes.length;
        selectVisible.indeterminate = chosen.length > 0 && chosen.length < checkboxes.length;
      }
    };

    checkboxes.forEach((checkbox) => {
      checkbox.addEventListener("click", (event) => {
        if (event.shiftKey && lastChecked) {
          const start = checkboxes.indexOf(lastChecked);
          const end = checkboxes.indexOf(checkbox);
          const [low, high] = start < end ? [start, end] : [end, start];
          for (let index = low; index <= high; index += 1) {
            checkboxes[index].checked = checkbox.checked;
          }
        }
        lastChecked = checkbox;
        updateToolbar();
      });
    });

    if (selectVisible) {
      selectVisible.addEventListener("change", () => {
        checkboxes.forEach((checkbox) => {
          checkbox.checked = selectVisible.checked;
        });
        updateToolbar();
      });
    }

    document.querySelectorAll("[data-select-member]").forEach((button) => {
      button.addEventListener("click", () => {
        const key = button.dataset.selectMember;
        checkboxes.forEach((checkbox) => {
          if (checkbox.dataset.memberKey === key) checkbox.checked = true;
        });
        updateToolbar();
        toolbar.scrollIntoView({behavior: "smooth", block: "nearest"});
      });
    });

    toolbar.querySelector("[data-clear-selection]")?.addEventListener("click", () => {
      checkboxes.forEach((checkbox) => {
        checkbox.checked = false;
      });
      lastChecked = null;
      updateToolbar();
    });

    bulkForm.addEventListener("submit", (event) => {
      const chosen = selected();
      if (!chosen.length) {
        event.preventDefault();
        return;
      }
      if (bulkForm.dataset.submitted === "true") {
        event.preventDefault();
        return;
      }
      const submitter = event.submitter;
      if (submitter?.hasAttribute("data-confirm-bulk")) {
        const decision = submitter.dataset.bulkDecision || "change";
        const total = totalNode?.textContent || "0.00";
        const confirmed = window.confirm(
          `${decision.charAt(0).toUpperCase()}${decision.slice(1)} ${chosen.length} selected payments totaling ${total} ISK?\n\nThis can be corrected later from the matching status tab.`,
        );
        if (!confirmed) {
          event.preventDefault();
          return;
        }
      }
      bulkForm.dataset.submitted = "true";
      toolbar.classList.add("is-submitting");
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && selected().length) {
        checkboxes.forEach((checkbox) => {
          checkbox.checked = false;
        });
        updateToolbar();
      }
    });

    updateToolbar();
  };

  const setupDecisionSafety = () => {
    document.querySelectorAll(".tax-quick-decision").forEach((form) => {
      form.addEventListener("submit", (event) => {
        if (form.dataset.submitted === "true") {
          event.preventDefault();
          return;
        }
        const submitter = event.submitter;
        const decision = submitter?.dataset.confirmSingle;
        if (decision) {
          const confirmed = window.confirm(
            `${decision.charAt(0).toUpperCase()}${decision.slice(1)} this payment? You can correct it later from its status tab.`,
          );
          if (!confirmed) {
            event.preventDefault();
            return;
          }
        }
        form.dataset.submitted = "true";
        form.classList.add("is-submitting");
      });
    });
  };

  setupAuditPolling();
  setupPaymentFilters();
  setupDensityToggle();
  setupPaymentSelection();
  setupDecisionSafety();
})();
