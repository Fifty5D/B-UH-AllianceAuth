"""Moon Tax URL routes."""

from django.urls import path

from . import views

app_name = "buh_moon_tax"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("periods/<int:period_id>/", views.period_detail, name="period"),
    path("payments/", views.payment_review, name="payments"),
    path("payments/decide/", views.decide_payment_view, name="decide_payment"),
    path(
        "payments/bulk-decide/",
        views.bulk_decide_payments,
        name="bulk_decide_payments",
    ),
    path("audit/run/", views.run_audit, name="run_audit"),
    path("audit/<int:audit_id>/status/", views.audit_status, name="audit_status"),
    path("export.csv", views.export_csv, name="export_csv"),
]
