from django.contrib.auth.models import Permission
from django.test import TestCase

from buh_moon_tax.access_roles import apply_role_presets


class RolePresetSafetyTests(TestCase):
    def test_normal_setup_preserves_removed_permission(self):
        member, _ = apply_role_presets(force=True)
        permission = Permission.objects.get(
            content_type__app_label="buh_moon_tax",
            codename="view_mining_values",
        )
        member.permissions.remove(permission)

        apply_role_presets()

        self.assertFalse(member.permissions.filter(pk=permission.pk).exists())

    def test_explicit_repair_reapplies_starter_permissions(self):
        member, _ = apply_role_presets(force=True)
        permission = Permission.objects.get(
            content_type__app_label="buh_moon_tax",
            codename="view_mining_values",
        )
        member.permissions.remove(permission)

        apply_role_presets(force=True)

        self.assertTrue(member.permissions.filter(pk=permission.pk).exists())
