import datetime as dt
from decimal import Decimal

from allianceauth.eveonline.models import EveCharacter
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.test import TestCase
from django.urls import reverse
from django.utils.timezone import now

from buh_moon_tax.models import (
    PaymentAllocation,
    PaymentCandidate,
    TaxAssessment,
    TaxConfiguration,
    TaxPeriod,
)


class PermissionBoundaryTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.one = get_user_model().objects.create_user("member-one")
        cls.two = get_user_model().objects.create_user("member-two")
        for offset, user in enumerate((cls.one, cls.two), start=1):
            character = EveCharacter.objects.create(
                character_id=90000000 + offset,
                character_name=f"Test Pilot {offset}",
                corporation_id=98000001,
                corporation_name="Bureau of Unified Harvesting",
            )
            user.profile.main_character = character
            user.profile.save(update_fields=["main_character"])
        permissions = Permission.objects.filter(
            content_type__app_label="buh_moon_tax",
            codename__in=("view_moon_tax", "view_own_tax", "view_mining_values"),
        )
        cls.one.user_permissions.add(*permissions)
        base = now() - dt.timedelta(days=6)
        cls.period = TaxPeriod.objects.create(
            source_started_at=base - dt.timedelta(days=20),
            structure_id=88,
            structure_name="Private Athanor",
            corporation_id=99,
            corporation_name="B-UH",
            extraction_started_at=base - dt.timedelta(days=20),
            pop_at=base,
            closes_at=base + dt.timedelta(days=3),
            due_at=base + dt.timedelta(days=3),
            tax_rate=Decimal(5),
            allowed_recipients=[
                {"kind": "CHARACTER", "id": 955001, "name": "Fifty5D"}
            ],
            status=TaxPeriod.Status.DUE,
            gross_value=Decimal(1000999),
            tax_due=Decimal(10049),
        )
        TaxAssessment.objects.create(
            period=cls.period,
            billing_key=f"user:{cls.one.pk}",
            auth_user=cls.one,
            display_name="VISIBLE-ACCOUNT",
            gross_value=Decimal(1000),
            tax_due=Decimal(50),
            due_at=cls.period.due_at,
        )
        TaxAssessment.objects.create(
            period=cls.period,
            billing_key=f"user:{cls.two.pk}",
            auth_user=cls.two,
            display_name="HIDDEN-ACCOUNT",
            gross_value=Decimal(999999),
            tax_due=Decimal(9999),
            due_at=cls.period.due_at,
        )

    def test_member_dashboard_never_renders_other_accounts(self):
        self.client.force_login(
            self.one, backend="django.contrib.auth.backends.ModelBackend"
        )
        response = self.client.get(reverse("buh_moon_tax:dashboard"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "VISIBLE-ACCOUNT")
        self.assertNotContains(response, "HIDDEN-ACCOUNT")
        self.assertNotContains(response, "999,999")

    def test_member_period_totals_and_recipients_are_scoped(self):
        self.client.force_login(
            self.one, backend="django.contrib.auth.backends.ModelBackend"
        )
        response = self.client.get(
            reverse("buh_moon_tax:period", args=(self.period.pk,))
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "VISIBLE-ACCOUNT")
        self.assertContains(response, "Fifty5D")
        self.assertNotContains(response, "HIDDEN-ACCOUNT")
        self.assertNotContains(response, "999,999")

    def test_user_without_app_permission_is_denied(self):
        self.client.force_login(
            self.two, backend="django.contrib.auth.backends.ModelBackend"
        )
        response = self.client.get(reverse("buh_moon_tax:dashboard"))
        self.assertEqual(response.status_code, 403)


class PaymentReviewWorkspaceTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.director = get_user_model().objects.create_user("payments-director")
        cls.member = get_user_model().objects.create_user("payment-member")
        cls.outsider = get_user_model().objects.create_user("payment-outsider")
        for offset, user in enumerate((cls.director, cls.member, cls.outsider)):
            character = EveCharacter.objects.create(
                character_id=91000000 + offset,
                character_name=f"Payment Pilot {offset}",
                corporation_id=98000001,
                corporation_name="Bureau of Unified Harvesting",
            )
            user.profile.main_character = character
            user.profile.save(update_fields=["main_character"])
        permissions = Permission.objects.filter(
            content_type__app_label="buh_moon_tax",
            codename__in=(
                "view_moon_tax",
                "view_payment_evidence",
                "review_payments",
            ),
        )
        cls.director.user_permissions.add(*permissions)
        cls.member.user_permissions.add(
            *permissions.exclude(codename="review_payments")
        )
        TaxConfiguration.objects.create(
            singleton_id=1,
            notify_member_payment_decision=False,
        )
        cls.member_payment = PaymentCandidate.objects.create(
            source=PaymentCandidate.Source.WALLET,
            source_key="wallet:review-member",
            payer_character_id=91000001,
            payer_character_name="Payment Alt Alpha",
            auth_user=cls.member,
            recipient_id=955001,
            recipient_name="Fifty5D",
            amount=Decimal("125.50"),
            occurred_at=now() - dt.timedelta(days=2),
            reference="moon tax alpha",
        )
        cls.outsider_payment = PaymentCandidate.objects.create(
            source=PaymentCandidate.Source.CONTRACT,
            source_key="contract:review-outsider",
            payer_character_id=91000002,
            payer_character_name="Payment Alt Bravo",
            auth_user=cls.outsider,
            recipient_id=98000001,
            recipient_name="Bureau of Unified Harvesting",
            amount=Decimal("900.00"),
            occurred_at=now() - dt.timedelta(days=1),
            reference="contract beta",
        )

    def login_director(self):
        self.client.force_login(
            self.director,
            backend="django.contrib.auth.backends.ModelBackend",
        )

    def test_payment_page_uses_buttons_and_member_search(self):
        self.login_director()
        response = self.client.get(
            reverse("buh_moon_tax:payments"),
            {"status": "ALL", "q": "Payment Pilot 1"},
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Payment Pilot 1")
        self.assertNotContains(response, "Payment Pilot 2")
        self.assertContains(response, 'value="OLDEST_CARRY"')
        self.assertContains(response, 'id="tax-bulk-form"')
        self.assertNotContains(response, "Choose director decision")
        self.assertEqual(response.context["summary"]["count"], 1)

    def test_bulk_ignore_changes_every_selected_payment(self):
        self.login_director()
        response = self.client.post(
            reverse("buh_moon_tax:bulk_decide_payments"),
            {
                "payment_ids": [
                    self.member_payment.pk,
                    self.outsider_payment.pk,
                ],
                "decision": "IGNORE",
                "note": "Batch review",
            },
        )
        self.assertRedirects(response, reverse("buh_moon_tax:payments"))
        payments = PaymentCandidate.objects.filter(
            pk__in=(self.member_payment.pk, self.outsider_payment.pk)
        )
        self.assertEqual(
            set(payments.values_list("status", flat=True)),
            {PaymentCandidate.Status.IGNORED},
        )
        self.assertEqual(
            PaymentAllocation.objects.filter(payment__in=payments).count(),
            2,
        )

    def test_member_cannot_use_director_bulk_action(self):
        self.client.force_login(
            self.member,
            backend="django.contrib.auth.backends.ModelBackend",
        )
        response = self.client.post(
            reverse("buh_moon_tax:bulk_decide_payments"),
            {
                "payment_ids": [self.member_payment.pk],
                "decision": "IGNORE",
            },
        )
        self.assertEqual(response.status_code, 403)
        self.member_payment.refresh_from_db()
        self.assertEqual(
            self.member_payment.status,
            PaymentCandidate.Status.PENDING,
        )

    def test_system_exempt_payment_cannot_be_manually_reclassified(self):
        self.login_director()
        self.member_payment.status = PaymentCandidate.Status.EXEMPT
        self.member_payment.review_note = "[AUTO-EXEMPT] Test"
        self.member_payment.save(update_fields=("status", "review_note"))
        self.client.post(
            reverse("buh_moon_tax:decide_payment"),
            {
                "payment_id": self.member_payment.pk,
                "decision": "OLDEST_CARRY",
            },
        )
        self.member_payment.refresh_from_db()
        self.assertEqual(
            self.member_payment.status,
            PaymentCandidate.Status.EXEMPT,
        )
