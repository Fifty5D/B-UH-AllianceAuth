"""Permission-filtered Moon Tax dashboards and director workflow endpoints."""

from __future__ import annotations

import csv
from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Count, Q, Sum
from django.http import Http404, HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_GET, require_POST

from . import __version__, app_settings
from .access import has, has_app_access, require, visibility
from .forms import (
    BulkPaymentDecisionForm,
    PaymentDecisionForm,
    PaymentFilterForm,
)
from .models import (
    ZERO,
    AuditRun,
    MiningLine,
    PaymentCandidate,
    TaxAssessment,
    TaxConfiguration,
    TaxPeriod,
)
from .payments import decide_payment
from .tasks import ACTIVE_STATUSES, create_audit, expire_stale_audits, refresh_sources

PAYMENT_DECISION_MAP = {
    "OLDEST_CARRY": "oldest_carryover",
    "OLDEST_OVERAGE": "oldest_overage",
    "DONATION": "donation",
    "IGNORE": "ignore",
    "REJECT": "reject",
    "RESET_PENDING": "pending",
}


def app_access_required(view_func):
    @login_required
    @wraps(view_func)
    def wrapped(request, *args, **kwargs):
        if not has_app_access(request.user):
            raise PermissionDenied("You do not have access to Moon Tax.")
        return view_func(request, *args, **kwargs)

    return wrapped


def _assessment_scope(user):
    queryset = TaxAssessment.objects.select_related("period", "auth_user")
    if has(user, "view_all_tax"):
        if not has(user, "view_unlinked_miners"):
            queryset = queryset.filter(auth_user__isnull=False)
        return queryset
    if has(user, "view_own_tax"):
        return queryset.filter(auth_user=user)
    return queryset.none()


def _payment_scope(user):
    queryset = PaymentCandidate.objects.select_related(
        "auth_user",
        "auth_user__profile",
        "auth_user__profile__main_character",
        "reviewed_by",
    )
    if has(user, "review_payments") or has(user, "view_all_tax"):
        return queryset
    if has(user, "view_payment_evidence"):
        return queryset.filter(auth_user=user)
    return queryset.none()


def _reviewable_payment_scope(user):
    """System-excluded evidence can be viewed, but not manually reallocated."""

    return _payment_scope(user).exclude(status=PaymentCandidate.Status.EXEMPT)


def _payment_return_url(request: HttpRequest) -> str:
    """Return only to the local payment screen after a decision."""

    fallback = reverse("buh_moon_tax:payments")
    target = request.POST.get("return_to", "")
    if (
        target.startswith(fallback)
        and url_has_allowed_host_and_scheme(
            target,
            allowed_hosts={request.get_host()},
            require_https=request.is_secure(),
        )
    ):
        return target
    return fallback


def _decorate_payments(payments):
    """Attach stable UI labels without making templates traverse nullable profiles."""

    for payment in payments:
        user = payment.auth_user
        main_character = None
        if user is not None:
            profile = getattr(user, "profile", None)
            main_character = getattr(profile, "main_character", None)
        if main_character is not None:
            payment.member_label = main_character.character_name
            payment.member_secondary = user.username
            payment.member_key = f"user-{user.pk}"
        elif user is not None:
            payment.member_label = user.username
            payment.member_secondary = "Linked Auth account"
            payment.member_key = f"user-{user.pk}"
        else:
            payment.member_label = payment.payer_character_name or "Unlinked payer"
            payment.member_secondary = "Not linked to an Auth account"
            payment.member_key = f"character-{payment.payer_character_id or payment.pk}"
    return payments


def _periods_with_visible_totals(assessments, *, limit=12):
    """Attach totals from the caller's permission-filtered assessment scope."""

    periods = list(
        TaxPeriod.objects.filter(assessments__in=assessments)
        .distinct()
        .order_by("-pop_at")[:limit]
    )
    if not periods:
        return periods
    totals = {
        row["period_id"]: row
        for row in assessments.filter(period_id__in=[item.pk for item in periods])
        .values("period_id")
        .annotate(
            visible_gross=Sum("gross_value"),
            visible_tax=Sum("tax_due"),
            visible_paid=Sum("approved_paid"),
        )
    }
    for period in periods:
        row = totals.get(period.pk, {})
        period.visible_gross = row.get("visible_gross") or ZERO
        period.visible_tax = row.get("visible_tax") or ZERO
        period.visible_paid = row.get("visible_paid") or ZERO
        period.visible_outstanding = max(
            ZERO, period.visible_tax - period.visible_paid
        )
    return periods


@app_access_required
@require_GET
def dashboard(request: HttpRequest) -> HttpResponse:
    permissions = visibility(request.user)
    assessments = _assessment_scope(request.user)
    totals = assessments.aggregate(
        bills=Count("pk"), tax=Sum("tax_due"), paid=Sum("approved_paid")
    )
    totals["tax"] = totals["tax"] or ZERO
    totals["paid"] = totals["paid"] or ZERO
    totals["outstanding"] = max(ZERO, totals["tax"] - totals["paid"])
    pending_payments = _payment_scope(request.user).filter(
        status=PaymentCandidate.Status.PENDING
    )
    latest_audit = (
        AuditRun.objects.order_by("-queued_at").first()
        if has(request.user, "run_tax_audit") or has(request.user, "view_all_tax")
        else None
    )
    periods = _periods_with_visible_totals(assessments)
    context = {
        "app_name": app_settings.APP_NAME,
        "app_version": __version__,
        "permissions": permissions,
        "totals": totals,
        "periods": periods,
        "assessments": assessments.order_by("-period__pop_at", "display_name")[:25],
        "pending_payments": pending_payments.order_by("occurred_at")[:20],
        "pending_payment_count": pending_payments.count(),
        "latest_audit": latest_audit,
        "config": TaxConfiguration.objects.filter(singleton_id=1).first(),
    }
    return render(request, "buh_moon_tax/dashboard.html", context)


@app_access_required
@require_GET
def period_detail(request: HttpRequest, period_id: int) -> HttpResponse:
    period = get_object_or_404(TaxPeriod, pk=period_id)
    assessments = _assessment_scope(request.user).filter(period=period)
    if not assessments.exists():
        raise Http404
    lines = MiningLine.objects.filter(period=period)
    if not has(request.user, "view_all_tax"):
        lines = lines.filter(auth_user=request.user)
    elif not has(request.user, "view_unlinked_miners"):
        lines = lines.filter(auth_user__isnull=False)
    visible_totals = assessments.aggregate(
        gross=Sum("gross_value"), tax=Sum("tax_due"), paid=Sum("approved_paid")
    )
    visible_totals = {
        "gross": visible_totals["gross"] or ZERO,
        "tax": visible_totals["tax"] or ZERO,
        "paid": visible_totals["paid"] or ZERO,
    }
    visible_totals["outstanding"] = max(
        ZERO, visible_totals["tax"] - visible_totals["paid"]
    )
    context = {
        "app_name": app_settings.APP_NAME,
        "permissions": visibility(request.user),
        "period": period,
        "assessments": assessments,
        "visible_totals": visible_totals,
        "lines": lines.select_related("auth_user").order_by(
            "character_name", "raw_type_name", "ledger_day"
        ),
    }
    return render(request, "buh_moon_tax/period_detail.html", context)


@app_access_required
@require_GET
def payment_review(request: HttpRequest) -> HttpResponse:
    require(request.user, "view_payment_evidence")
    payment_scope = _payment_scope(request.user)
    status_counts = {
        row["status"]: row["count"]
        for row in payment_scope.values("status").annotate(count=Count("pk"))
    }
    recipient_choices = list(
        payment_scope.order_by("recipient_name", "recipient_id")
        .values_list("recipient_id", "recipient_name")
        .distinct()
    )
    payments = payment_scope.prefetch_related("allocations__assessment__period")
    status = request.GET.get("status", "PENDING")
    valid_statuses = {choice for choice, _ in PaymentCandidate.Status.choices}
    if status in valid_statuses:
        payments = payments.filter(status=status)
    elif status != "ALL":
        status = "PENDING"
        payments = payments.filter(status=status)

    filter_form = PaymentFilterForm(
        request.GET or None,
        recipient_choices=recipient_choices,
    )
    sort = "oldest"
    per_page = 50
    if filter_form.is_valid():
        cleaned = filter_form.cleaned_data
        search = (cleaned.get("q") or "").strip()
        if search:
            payments = payments.filter(
                Q(payer_character_name__icontains=search)
                | Q(auth_user__username__icontains=search)
                | Q(
                    auth_user__profile__main_character__character_name__icontains=search
                )
                | Q(recipient_name__icontains=search)
                | Q(reference__icontains=search)
            )
        if cleaned.get("source"):
            payments = payments.filter(source=cleaned["source"])
        if cleaned.get("recipient"):
            payments = payments.filter(recipient_id=cleaned["recipient"])
        if cleaned.get("min_amount") is not None:
            payments = payments.filter(amount__gte=cleaned["min_amount"])
        if cleaned.get("max_amount") is not None:
            payments = payments.filter(amount__lte=cleaned["max_amount"])
        if cleaned.get("date_from"):
            payments = payments.filter(occurred_at__date__gte=cleaned["date_from"])
        if cleaned.get("date_to"):
            payments = payments.filter(occurred_at__date__lte=cleaned["date_to"])
        sort = cleaned.get("sort") or "oldest"
        per_page = int(cleaned.get("per_page") or 50)

    orderings = {
        "oldest": ("occurred_at", "pk"),
        "newest": ("-occurred_at", "-pk"),
        "highest": ("-amount", "occurred_at", "pk"),
        "lowest": ("amount", "occurred_at", "pk"),
        "member": ("payer_character_name", "occurred_at", "pk"),
    }
    payments = payments.order_by(*orderings.get(sort, orderings["oldest"]))
    summary = payments.aggregate(
        count=Count("pk"),
        total=Sum("amount"),
        linked_members=Count("auth_user", distinct=True),
        unlinked_members=Count(
            "payer_character_id",
            filter=Q(auth_user__isnull=True),
            distinct=True,
        ),
    )
    summary["total"] = summary["total"] or ZERO
    summary["members"] = (
        summary.pop("linked_members") + summary.pop("unlinked_members")
    )

    paginator = Paginator(payments, per_page)
    page_obj = paginator.get_page(request.GET.get("page"))
    page_payments = _decorate_payments(list(page_obj.object_list))

    status_params = request.GET.copy()
    status_params.pop("page", None)
    status_links = []
    all_count = sum(status_counts.values())
    for value, label in (("ALL", "All"), *PaymentCandidate.Status.choices):
        status_params["status"] = value
        status_links.append(
            {
                "value": value,
                "label": label,
                "count": all_count if value == "ALL" else status_counts.get(value, 0),
                "query": status_params.urlencode(),
            }
        )

    pagination_params = request.GET.copy()
    pagination_params.pop("page", None)
    context = {
        "app_name": app_settings.APP_NAME,
        "app_version": __version__,
        "permissions": visibility(request.user),
        "payments": page_payments,
        "page_obj": page_obj,
        "summary": summary,
        "active_status": status,
        "status_links": status_links,
        "filter_form": filter_form,
        "pagination_query": pagination_params.urlencode(),
        "has_active_filters": any(
            request.GET.get(key)
            for key in (
                "q",
                "source",
                "recipient",
                "min_amount",
                "max_amount",
                "date_from",
                "date_to",
            )
        ),
    }
    return render(request, "buh_moon_tax/payments.html", context)


@app_access_required
@require_POST
def decide_payment_view(request: HttpRequest) -> HttpResponse:
    require(request.user, "review_payments")
    form = PaymentDecisionForm(
        request.POST,
        payment_queryset=_reviewable_payment_scope(request.user),
    )
    if not form.is_valid():
        messages.error(
            request, "Payment decision was not saved. Refresh and try again."
        )
        return redirect(_payment_return_url(request))
    payment = form.cleaned_data["payment_id"]
    decision = form.cleaned_data["decision"]
    decide_payment(
        payment,
        disposition=PAYMENT_DECISION_MAP[decision],
        director=request.user,
        note=form.cleaned_data["note"],
    )
    messages.success(
        request,
        f"{dict(PaymentDecisionForm.Decision.choices)[decision]}: "
        f"{payment.amount:,.2f} ISK from "
        f"{payment.payer_character_name or 'the payer'}.",
    )
    return redirect(_payment_return_url(request))


@app_access_required
@require_POST
def bulk_decide_payments(request: HttpRequest) -> HttpResponse:
    require(request.user, "review_payments")
    payment_scope = _reviewable_payment_scope(request.user)
    form = BulkPaymentDecisionForm(
        request.POST,
        payment_queryset=payment_scope,
    )
    if not form.is_valid():
        messages.error(
            request,
            "No payments were changed. Select at least one visible payment and try again.",
        )
        return redirect(_payment_return_url(request))

    selected_ids = list(
        form.cleaned_data["payment_ids"].values_list("pk", flat=True)
    )
    decision = form.cleaned_data["decision"]
    note = form.cleaned_data["note"]
    with transaction.atomic():
        selected = list(
            payment_scope.select_for_update()
            .filter(pk__in=selected_ids)
            .order_by("occurred_at", "pk")
        )
        total = sum((payment.amount for payment in selected), ZERO)
        for payment in selected:
            decide_payment(
                payment,
                disposition=PAYMENT_DECISION_MAP[decision],
                director=request.user,
                note=note,
            )
    messages.success(
        request,
        f"{dict(PaymentDecisionForm.Decision.choices)[decision]} for "
        f"{len(selected)} payment(s), totaling {total:,.2f} ISK.",
    )
    return redirect(_payment_return_url(request))


@app_access_required
@require_POST
def run_audit(request: HttpRequest) -> HttpResponse:
    require(request.user, "run_tax_audit")
    expired = expire_stale_audits()
    if expired:
        messages.warning(
            request,
            f"Released {expired} stale audit run(s) left behind by an earlier worker restart.",
        )
    active = AuditRun.objects.filter(
        status__in=ACTIVE_STATUSES
    ).order_by("-queued_at").first()
    if active:
        messages.info(request, f"Audit #{active.pk} is already {active.get_status_display().lower()}.")
        return redirect("buh_moon_tax:dashboard")
    audit = create_audit(AuditRun.Trigger.MANUAL, request.user)
    refresh_sources.delay(audit.pk)
    messages.success(
        request,
        f"Audit #{audit.pk} is queued. Source refreshes run first; the page will show its result.",
    )
    return redirect("buh_moon_tax:dashboard")


@app_access_required
@require_GET
def audit_status(request: HttpRequest, audit_id: int) -> JsonResponse:
    require(request.user, "run_tax_audit")
    audit = get_object_or_404(AuditRun, pk=audit_id)
    return JsonResponse(
        {
            "id": audit.pk,
            "status": audit.status,
            "status_label": audit.get_status_display(),
            "summary": audit.summary,
            "warnings": audit.warnings,
            "error": audit.error,
            "finished_at": audit.finished_at.isoformat() if audit.finished_at else None,
        }
    )


def _csv_safe(value):
    text = str(value or "")
    return f"'{text}" if text.startswith(("=", "+", "-", "@")) else text


@app_access_required
@require_GET
def export_csv(request: HttpRequest) -> HttpResponse:
    require(request.user, "export_tax_data")
    permissions = visibility(request.user)
    assessments = _assessment_scope(request.user)
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = 'attachment; filename="buh-moon-tax.csv"'
    writer = csv.writer(response)
    header = ["Period", "Payer / account", "Status", "Due (UTC)"]
    if permissions["view_mining_values"]:
        header += ["Mined value (ISK)", "Tax due (ISK)", "Approved paid (ISK)", "Outstanding (ISK)"]
    writer.writerow(header)
    for assessment in assessments.order_by("period__pop_at", "display_name"):
        row = [
            _csv_safe(str(assessment.period)),
            _csv_safe(assessment.display_name),
            assessment.get_status_display(),
            assessment.due_at.isoformat(),
        ]
        if permissions["view_mining_values"]:
            row += [
                assessment.gross_value,
                assessment.tax_due,
                assessment.approved_paid,
                assessment.outstanding,
            ]
        writer.writerow(row)
    return response
