"""B-UH Moon Tax."""

__version__ = "0.2.2"
__title__ = "B-UH Moon Tax"
