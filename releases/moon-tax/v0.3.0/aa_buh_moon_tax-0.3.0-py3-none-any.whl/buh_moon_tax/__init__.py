"""B-UH Moon Tax."""

__version__ = "0.3.0"
__title__ = "B-UH Moon Tax"
