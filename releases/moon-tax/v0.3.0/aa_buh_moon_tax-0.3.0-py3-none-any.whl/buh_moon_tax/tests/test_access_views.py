import datetime as dt
from decimal import Decimal

from allianceauth.eveonline.models import EveCharacter
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.test import TestCase
from django.urls import reverse
from django.utils.timezone import now

from buh_moon_tax.models import (
    PaymentAllocation,
    PaymentCandidate,
    PaymentRecipient,
    StructureTaxPolicy,
    TaxAssessment,
    TaxConfiguration,
    TaxPeriod,
)


class PermissionBoundaryTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.one = get_user_model().objects.create_user("member-one")
        cls.two = get_user_model().objects.create_user("member-two")
        for offset, user in enumerate((cls.one, cls.two), start=1):
            character = EveCharacter.objects.create(
                character_id=90000000 + offset,
                character_name=f"Test Pilot {offset}",
                corporation_id=98000001,
                corporation_name="Bureau of Unified Harvesting",
            )
            user.profile.main_character = character
            user.profile.save(update_fields=["main_character"])
        permissions = Permission.objects.filter(
            content_type__app_label="buh_moon_tax",
            codename__in=("view_moon_tax", "view_own_tax", "view_mining_values"),
        )
        cls.one.user_permissions.add(*permissions)
        base = now() - dt.timedelta(days=6)
        cls.period = TaxPeriod.objects.create(
            source_started_at=base - dt.timedelta(days=20),
            structure_id=88,
            structure_name="Private Athanor",
            corporation_id=99,
            corporation_name="B-UH",
            extraction_started_at=base - dt.timedelta(days=20),
            pop_at=base,
            closes_at=base + dt.timedelta(days=3),
            due_at=base + dt.timedelta(days=3),
            tax_rate=Decimal(5),
            allowed_recipients=[
                {"kind": "CHARACTER", "id": 955001, "name": "Fifty5D"}
            ],
            status=TaxPeriod.Status.DUE,
            gross_value=Decimal(1000999),
            tax_due=Decimal(10049),
        )
        TaxAssessment.objects.create(
            period=cls.period,
            billing_key=f"user:{cls.one.pk}",
            auth_user=cls.one,
            display_name="VISIBLE-ACCOUNT",
            gross_value=Decimal(1000),
            tax_due=Decimal(50),
            due_at=cls.period.due_at,
        )
        TaxAssessment.objects.create(
            period=cls.period,
            billing_key=f"user:{cls.two.pk}",
            auth_user=cls.two,
            display_name="HIDDEN-ACCOUNT",
            gross_value=Decimal(999999),
            tax_due=Decimal(9999),
            due_at=cls.period.due_at,
        )

    def test_member_dashboard_never_renders_other_accounts(self):
        self.client.force_login(
            self.one, backend="django.contrib.auth.backends.ModelBackend"
        )
        response = self.client.get(reverse("buh_moon_tax:dashboard"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "VISIBLE-ACCOUNT")
        self.assertNotContains(response, "HIDDEN-ACCOUNT")
        self.assertNotContains(response, "999,999")

    def test_member_period_totals_and_recipients_are_scoped(self):
        self.client.force_login(
            self.one, backend="django.contrib.auth.backends.ModelBackend"
        )
        response = self.client.get(
            reverse("buh_moon_tax:period", args=(self.period.pk,))
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "VISIBLE-ACCOUNT")
        self.assertContains(response, "Fifty5D")
        self.assertNotContains(response, "HIDDEN-ACCOUNT")
        self.assertNotContains(response, "999,999")

    def test_user_without_app_permission_is_denied(self):
        self.client.force_login(
            self.two, backend="django.contrib.auth.backends.ModelBackend"
        )
        response = self.client.get(reverse("buh_moon_tax:dashboard"))
        self.assertEqual(response.status_code, 403)


class PaymentReviewWorkspaceTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.director = get_user_model().objects.create_user("payments-director")
        cls.member = get_user_model().objects.create_user("payment-member")
        cls.outsider = get_user_model().objects.create_user("payment-outsider")
        for offset, user in enumerate((cls.director, cls.member, cls.outsider)):
            character = EveCharacter.objects.create(
                character_id=91000000 + offset,
                character_name=f"Payment Pilot {offset}",
                corporation_id=98000001,
                corporation_name="Bureau of Unified Harvesting",
            )
            user.profile.main_character = character
            user.profile.save(update_fields=["main_character"])
        permissions = Permission.objects.filter(
            content_type__app_label="buh_moon_tax",
            codename__in=(
                "view_moon_tax",
                "view_payment_evidence",
                "review_payments",
            ),
        )
        cls.director.user_permissions.add(*permissions)
        cls.member.user_permissions.add(
            *permissions.exclude(codename="review_payments")
        )
        TaxConfiguration.objects.create(
            singleton_id=1,
            notify_member_payment_decision=False,
        )
        cls.member_payment = PaymentCandidate.objects.create(
            source=PaymentCandidate.Source.WALLET,
            source_key="wallet:review-member",
            payer_character_id=91000001,
            payer_character_name="Payment Alt Alpha",
            auth_user=cls.member,
            recipient_id=955001,
            recipient_name="Fifty5D",
            amount=Decimal("125.50"),
            occurred_at=now() - dt.timedelta(days=2),
            reference="moon tax alpha",
        )
        cls.outsider_payment = PaymentCandidate.objects.create(
            source=PaymentCandidate.Source.CONTRACT,
            source_key="contract:review-outsider",
            payer_character_id=91000002,
            payer_character_name="Payment Alt Bravo",
            auth_user=cls.outsider,
            recipient_id=98000001,
            recipient_name="Bureau of Unified Harvesting",
            amount=Decimal("900.00"),
            occurred_at=now() - dt.timedelta(days=1),
            reference="contract beta",
        )

    def login_director(self):
        self.client.force_login(
            self.director,
            backend="django.contrib.auth.backends.ModelBackend",
        )

    def test_payment_page_uses_buttons_and_member_search(self):
        self.login_director()
        response = self.client.get(
            reverse("buh_moon_tax:payments"),
            {"status": "ALL", "q": "Payment Pilot 1"},
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Payment Pilot 1")
        self.assertNotContains(response, "Payment Pilot 2")
        self.assertContains(response, 'value="OLDEST_CARRY"')
        self.assertContains(response, 'id="tax-bulk-form"')
        self.assertContains(
            response,
            reverse(
                "buh_moon_tax:decide_payment_direct",
                args=(self.member_payment.pk,),
            ),
        )
        self.assertContains(response, "data-payment-drag")
        self.assertContains(response, "data-decision-dock")
        self.assertNotContains(response, "Choose director decision")
        self.assertEqual(response.context["summary"]["count"], 1)

    def test_bulk_ignore_changes_every_selected_payment(self):
        self.login_director()
        response = self.client.post(
            reverse("buh_moon_tax:bulk_decide_payments"),
            {
                "payment_ids": [
                    self.member_payment.pk,
                    self.outsider_payment.pk,
                ],
                "decision": "IGNORE",
                "note": "Batch review",
            },
        )
        self.assertRedirects(response, reverse("buh_moon_tax:payments"))
        payments = PaymentCandidate.objects.filter(
            pk__in=(self.member_payment.pk, self.outsider_payment.pk)
        )
        self.assertEqual(
            set(payments.values_list("status", flat=True)),
            {PaymentCandidate.Status.IGNORED},
        )
        self.assertEqual(
            PaymentAllocation.objects.filter(payment__in=payments).count(),
            2,
        )

    def test_row_accept_has_a_dedicated_working_endpoint(self):
        self.login_director()
        response = self.client.post(
            reverse(
                "buh_moon_tax:decide_payment_direct",
                args=(self.member_payment.pk,),
            ),
            {"decision": "OLDEST_CARRY", "note": "One-click row review"},
            HTTP_X_REQUESTED_WITH="XMLHttpRequest",
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["ok"])
        self.member_payment.refresh_from_db()
        self.assertEqual(self.member_payment.status, PaymentCandidate.Status.OVERAGE)

    def test_member_cannot_use_director_bulk_action(self):
        self.client.force_login(
            self.member,
            backend="django.contrib.auth.backends.ModelBackend",
        )
        response = self.client.post(
            reverse("buh_moon_tax:bulk_decide_payments"),
            {
                "payment_ids": [self.member_payment.pk],
                "decision": "IGNORE",
            },
        )
        self.assertEqual(response.status_code, 403)
        self.member_payment.refresh_from_db()
        self.assertEqual(
            self.member_payment.status,
            PaymentCandidate.Status.PENDING,
        )

    def test_system_exempt_payment_cannot_be_manually_reclassified(self):
        self.login_director()
        self.member_payment.status = PaymentCandidate.Status.EXEMPT
        self.member_payment.review_note = "[AUTO-EXEMPT] Test"
        self.member_payment.save(update_fields=("status", "review_note"))
        self.client.post(
            reverse("buh_moon_tax:decide_payment"),
            {
                "payment_id": self.member_payment.pk,
                "decision": "OLDEST_CARRY",
            },
        )
        self.member_payment.refresh_from_db()
        self.assertEqual(
            self.member_payment.status,
            PaymentCandidate.Status.EXEMPT,
        )


class MemberPreviewAndPolicyTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.director = get_user_model().objects.create_user("preview-director")
        cls.member = get_user_model().objects.create_user("preview-member")
        cls.other = get_user_model().objects.create_user("preview-other")
        for offset, user in enumerate((cls.director, cls.member, cls.other), start=1):
            character = EveCharacter.objects.create(
                character_id=93000000 + offset,
                character_name=f"Preview Pilot {offset}",
                corporation_id=98000001,
                corporation_name="Bureau of Unified Harvesting",
            )
            user.profile.main_character = character
            user.profile.save(update_fields=["main_character"])
        director_permissions = Permission.objects.filter(
            content_type__app_label="buh_moon_tax",
            codename__in=(
                "view_moon_tax",
                "view_all_tax",
                "view_mining_values",
                "preview_member_view",
                "manage_tax_policy",
                "manage_bill_adjustments",
                "run_tax_audit",
            ),
        )
        cls.director.user_permissions.add(*director_permissions)
        member_permissions = Permission.objects.filter(
            content_type__app_label="buh_moon_tax",
            codename__in=("view_moon_tax", "view_own_tax", "view_mining_values"),
        )
        cls.member.user_permissions.add(*member_permissions)
        cls.config = TaxConfiguration.objects.create(
            singleton_id=1,
            default_tax_rate=Decimal("5.00"),
            notify_member_payment_decision=False,
        )
        cls.recipient = PaymentRecipient.objects.create(
            kind=PaymentRecipient.Kind.CHARACTER,
            entity_id=93000099,
            name="Member Investor",
        )
        base = now() - dt.timedelta(days=5)
        cls.period = TaxPeriod.objects.create(
            source_started_at=base - dt.timedelta(days=10),
            structure_id=445566,
            structure_name="Investor Athanor",
            corporation_id=98000001,
            corporation_name="B-UH",
            extraction_started_at=base - dt.timedelta(days=10),
            pop_at=base,
            closes_at=base + dt.timedelta(days=3),
            due_at=base + dt.timedelta(days=3),
            tax_rate=Decimal("5.00"),
            allowed_recipients=[
                {"kind": "CORPORATION", "id": 98000001, "name": "B-UH"}
            ],
            status=TaxPeriod.Status.DUE,
        )
        TaxAssessment.objects.create(
            period=cls.period,
            billing_key=f"user:{cls.member.pk}",
            auth_user=cls.member,
            display_name="MEMBER-PREVIEW-BILL",
            gross_value=Decimal(1000),
            calculated_tax_due=Decimal(50),
            tax_due=Decimal(50),
            due_at=cls.period.due_at,
        )
        TaxAssessment.objects.create(
            period=cls.period,
            billing_key=f"user:{cls.other.pk}",
            auth_user=cls.other,
            display_name="OTHER-HIDDEN-BILL",
            gross_value=Decimal(5000),
            calculated_tax_due=Decimal(250),
            tax_due=Decimal(250),
            due_at=cls.period.due_at,
        )

    def login(self):
        self.client.force_login(
            self.director,
            backend="django.contrib.auth.backends.ModelBackend",
        )

    def test_member_preview_uses_real_scope_and_blocks_mutation(self):
        self.login()
        response = self.client.post(
            reverse("buh_moon_tax:start_member_preview"),
            {"user_id": self.member.pk},
        )
        self.assertRedirects(response, reverse("buh_moon_tax:dashboard"))
        response = self.client.get(reverse("buh_moon_tax:dashboard"))
        self.assertContains(response, "Member POV · read only")
        self.assertContains(response, "MEMBER-PREVIEW-BILL")
        self.assertNotContains(response, "OTHER-HIDDEN-BILL")
        response = self.client.post(reverse("buh_moon_tax:run_audit"))
        self.assertEqual(response.status_code, 403)

    def test_per_athanor_policy_preserves_existing_period_snapshot(self):
        self.login()
        workspace = self.client.get(reverse("buh_moon_tax:policy"))
        self.assertContains(workspace, "Investor Athanor")
        self.assertContains(workspace, "Member Investor")
        self.assertContains(workspace, "data-recipient-search")
        response = self.client.post(
            reverse("buh_moon_tax:save_structure_policy"),
            {
                "structure_id": self.period.structure_id,
                "tax_rate": "7.5",
                "payment_recipients": [self.recipient.pk],
                "notes": "Member-funded Athanor",
            },
        )
        self.assertRedirects(response, reverse("buh_moon_tax:policy"))
        policy = StructureTaxPolicy.objects.get(structure_id=self.period.structure_id)
        self.assertEqual(policy.tax_rate, Decimal("7.5000"))
        self.assertEqual(list(policy.payment_recipients.all()), [self.recipient])
        self.period.refresh_from_db()
        self.assertEqual(self.period.tax_rate, Decimal("5.0000"))
        self.assertEqual(self.period.allowed_recipients[0]["name"], "B-UH")

    def test_director_can_waive_a_small_balance_from_period_workspace(self):
        self.login()
        bill = TaxAssessment.objects.get(display_name="MEMBER-PREVIEW-BILL")
        workspace = self.client.get(
            reverse("buh_moon_tax:period", args=(self.period.pk,))
        )
        self.assertContains(workspace, "Waive 50")
        response = self.client.post(
            reverse("buh_moon_tax:adjust_assessment", args=(bill.pk,)),
            {
                "action": "WAIVE_BALANCE",
                "reason": "Small Jita price variance",
            },
        )
        self.assertRedirects(
            response,
            reverse("buh_moon_tax:period", args=(self.period.pk,)),
        )
        bill.refresh_from_db()
        self.assertEqual(bill.tax_due, Decimal(0))
        self.assertEqual(bill.status, TaxAssessment.Status.WAIVED)

    def test_bill_adjustment_permission_cannot_escape_visible_account_scope(self):
        permission = Permission.objects.get(
            content_type__app_label="buh_moon_tax",
            codename="manage_bill_adjustments",
        )
        self.member.user_permissions.add(permission)
        hidden_bill = TaxAssessment.objects.get(display_name="OTHER-HIDDEN-BILL")
        self.client.force_login(
            self.member,
            backend="django.contrib.auth.backends.ModelBackend",
        )

        response = self.client.post(
            reverse("buh_moon_tax:adjust_assessment", args=(hidden_bill.pk,)),
            {
                "action": "WAIVE_BALANCE",
                "reason": "Must not cross account scope",
            },
        )

        self.assertEqual(response.status_code, 404)
        hidden_bill.refresh_from_db()
        self.assertEqual(hidden_bill.tax_due, Decimal(250))
