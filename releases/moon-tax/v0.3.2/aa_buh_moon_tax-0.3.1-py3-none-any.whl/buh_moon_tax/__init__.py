"""B-UH Moon Tax."""

__version__ = "0.3.1"
__title__ = "B-UH Moon Tax"
